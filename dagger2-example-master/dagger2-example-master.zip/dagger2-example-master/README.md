### Overview

This code sample shows how to use Dagger 2 with Retrofit, OkHttp, and Gson. 

For more context, see https://github.com/codepath/android_guides/wiki/Dependency-Injection-with-Dagger-2.
