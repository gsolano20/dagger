package com.codepath.daggerexample.di.scopes;

import javax.inject.Scope;

@Scope
public @interface UserScope {

}
